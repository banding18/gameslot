# Slot-Demo

Simple Web Slot Demo with Pragmatic Play API <br>
Create for learning. not for sell this code 100% free

currency: IDR <br>
Total Game: 9 <br>
type game : Slots <br>

Build with ChatGPT help

Demo Site : <a href="https://slot-demo.nandz.my.id">See Demo</a>

# Let's connect with me!
<p>
    <a href="https://nandz.my.id/" target="_blank"><img src="https://img.shields.io/badge/Website-https://nandz.my.id-blue?" /></a>
    <a href="https://nandz.store/" target="_blank"><img src="https://img.shields.io/badge/Store-https://nandz.store/-blue" /></a>
    <a href="https://facebook.com/128.192.i98i/" target="_blank"><img src="https://img.shields.io/badge/Facebook-Tinandar%20Hermawan-blue" /></a>
    <a href="https://twitter.com/prodbynandz" target="_blank"><img src="https://img.shields.io/badge/Twitter-Nandz-blue" /></a>
    <a href="https://instagram.com/@prodbynandz" target="_blank"><img src="https://img.shields.io/badge/Instagram-@prodbynandz-blue" /></a>
</p> 
